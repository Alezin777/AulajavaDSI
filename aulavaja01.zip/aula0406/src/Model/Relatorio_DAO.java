package Model;

import java.io.FileOutputStream;
import java.io.OutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import javax.swing.JOptionPane;

public class Relatorio_DAO {
    
    public static void imprime()throws Exception {

        Document doc = null;
        OutputStream os = null;

        try {

            //cria o documento tamanho A4, margens de 2,54cm
            doc = new Document(PageSize.A4, 72, 72, 72, 72);

            //cria a stream de saída
            os = new FileOutputStream("out.pdf");

            //associa a stream de saída ao
            PdfWriter.getInstance(doc, os);

            //abre o documento
            doc.open();

            //adiciona o texto ao PDF
            //fazer um joptionpene perguntando e colocando as variaveis dentro 
            JOptionPane.showInputDialog(null,"Qual ");
            Paragraph par = new Paragraph("                                                      Atestado                                                                                            ");
            doc.add(par);
            
            
            Paragraph per = new Paragraph(                                                                                                                     
                    "Atesto para os devidos fins que, conforme o resultado do exame médico, nome, por- tador do RG nº identificação, e Carteira "
                    + "Profissional nº identificação não se encon tra em condições para o trabalho, "
                    + " seu afastamento ser considerado de data a data");
            doc.add(per);

        } finally {

            if (doc != null) {

                //fechamento do documento
                doc.close();
            }

            if (os != null) {
                //fechamento da stream de saída
                os.close();
            }
        }
        
        Desktop.getDesktop().open(new File("out.pdf"));
    }
}
    

