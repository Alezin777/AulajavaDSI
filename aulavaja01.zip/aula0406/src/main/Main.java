package main;

import View.Splash_GUI;


public class Main {


    public static void main(String[] args) throws Exception {
        Model.Relatorio_DAO.imprime();
            //new Splash_GUI().setVisible(true);

    }
    
}
